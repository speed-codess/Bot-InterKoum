const Discord = require('discord.js')
const transcript = require("discord-html-transcripts")
const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ChannelType, SelectMenuBuilder } = require("discord.js")

module.exports = async (bot, interaction) => {

  if(interaction.type === Discord.InteractionType.ApplicationCommand) {

    let command = require(`../Commandes/${interaction.commandName}`)
    command.run(bot, interaction, interaction.options,)
  } 
}

module.exports = async (bot, interaction) => {


  
    if(interaction.type === Discord.InteractionType.ApplicationCommand) {

        let command = require(`../Commandes/${interaction.commandName}`)
        command.run(bot, interaction, interaction.options)
    }
    
    if(interaction.isButton()) {
        if(interaction.customId === "close") {
          let EmbedPermissionClose = new EmbedBuilder()
          .setColor("#545454")
          .setDescription(`<:no:1038466717262827540>    Vous n'avez pas la permission requise !`)
     
          if(!interaction.member.permissions.has(Discord.PermissionFlagsBits.ManageChannels)) return interaction.reply({embeds: [EmbedPermissionClose], ephemeral: true})
     
          let EmbedCloseTicket = new EmbedBuilder()
          .setColor("#545454")
          .setDescription(`Êtes-vous sûr de vouloir fermer le ticket ?`)
          let Button = new ActionRowBuilder()
          .addComponents(new ButtonBuilder()
            .setCustomId('oui')
            .setLabel("Oui")
            .setStyle(ButtonStyle.Success),
            new ButtonBuilder()
            .setCustomId('non')
            .setLabel("Non")
            .setStyle(ButtonStyle.Danger),
          );
          await interaction.reply({embeds: [EmbedCloseTicket], components: [Button]});
        }
        else if(interaction.customId === "oui") {
          let EmbedPermissionClose = new EmbedBuilder()
          .setColor("#545454")
          .setDescription(`<:Refuse:1041824767688314942>    Vous n'avez pas la permission requise !`)
     
          if(!interaction.member.permissions.has(Discord.PermissionFlagsBits.ManageChannels)) return interaction.reply({embeds: [EmbedPermissionClose], ephemeral: true})
     
          interaction.channel.delete();
        }
        else if(interaction.customId === "non") {
          let EmbedPermissionClose = new EmbedBuilder()
          .setColor("#545454")
          .setDescription(`<:Refuse:1041824767688314942>   Vous n'avez pas la permission requise !`)
     
          if(!interaction.member.permissions.has(Discord.PermissionFlagsBits.ManageChannels)) return interaction.reply({embeds: [EmbedPermissionClose], ephemeral: true})
     
          interaction.message.delete()
        }
        else if(interaction.customId === "transcript") {
     
          let EmbedSendTranscript = new EmbedBuilder()
          .setColor("#545454")
          .setDescription(`<:Valid:1041824643507568770>    Transcript envoyé avec succès !`)
          let EmbedTranscript = new EmbedBuilder()
          .setColor("#545454")
          .setDescription(`<:Transcript:1041824048763637901>    Transcript de ${interaction.message.embeds[0].description.split(" ")[0]}`)
          let EmbedPermissionTranscript = new EmbedBuilder()
          .setColor("#545454")
          .setDescription(`<:Refuse:1041824767688314942>    -  Vous n'avez pas la permission requise !`)
     
          if(!interaction.member.permissions.has(Discord.PermissionFlagsBits.ManageChannels)) return interaction.reply({embeds: [EmbedPermissionTranscript], ephemeral: true})
     
          await interaction.deferReply({ ephemeral: true })
          await bot.channels.cache.get("1045824608227573770").send( {embeds: [EmbedTranscript], files: [await transcript.createTranscript(interaction.channel)]})
          await interaction.editReply({embeds: [EmbedSendTranscript], ephemeral: true})
        }
      }
     
    if(interaction.isSelectMenu()) {
        if(interaction.customId === 'menuticket') {
          if(interaction.values == 'help','Achat') {
    const EmbedTicket1 = new EmbedBuilder()
    .setColor("#545454")
    .setTitle(`Comment Contacter le Support ?`)
    .setThumbnail(`https://cdn.discordapp.com/attachments/1038089543175389244/1045432185840218195/a_9.png`)
    .setDescription(`> Pour créer un ticket, il vous suffit juste de cliquer sur le menu déroulant ci-dessous et de sélectionner la catégorie qui convient le mieux à votre demande d'aide !`)
    .setTimestamp()
    .setFooter({ text: `${bot.user.username}`, iconURL: bot.user.displayAvatarURL({dynamic: true}) });
     
            const RowTicket = new ActionRowBuilder()
                    .addComponents(
              new SelectMenuBuilder()
              .setCustomId('menuticket')
              .setPlaceholder('Sélectionner le type de ticket que vous voulez !')
              .addOptions(
                {
                  label: `Besoin d'aide`,
                  description: `Ouvrir un ticket pour obtenir de l'aide`,
                  emoji: `<:TI:1045433853000560821> `,
                  value: `help`,
                },
                {
                  label: "Achat",
                  description: `Ouvrir un ticket pour passer un achat`,
                  emoji: '<:10359981363107144601:1045434422226321538> ',
                  value: "Achat",
                },
            ),
          );
            await interaction.deferUpdate();
            await interaction.editReply({embeds: [EmbedTicket1], components: [RowTicket]})
     
            let channel = await interaction.guild.channels.create({
            parent: "1036630053498388581",
            name: `help-${interaction.user.username}`,
            type: ChannelType.GuildText,
            permissionOverwrites: [
              {
                id: interaction.guild.roles.everyone,
                deny: [Discord.PermissionFlagsBits.ViewChannel],
              },
              {
                id: interaction.user,
                allow: [Discord.PermissionFlagsBits.SendMessages, Discord.PermissionFlagsBits.ViewChannel],
              },
            ],
            });
            let EmbedCreateChannel = new EmbedBuilder()
            .setColor("#545454")
            .setTitle('Ticket ouvert')
            .setThumbnail(`https://cdn.discordapp.com/attachments/1038089543175389244/1045432185840218195/a_9.png`)
            .setDescription("<@" + interaction.user.id + "> Voici votre ticket.\nExpliquez-nous en détail votre problème !")
            .setTimestamp()
            .setFooter({ text: `${bot.user.username}`, iconURL: bot.user.displayAvatarURL({dynamic: true}) });
            const Row = new ActionRowBuilder()
                  .addComponents(new ButtonBuilder()
              .setCustomId('close')
              .setLabel('Fermer le ticket')
              .setEmoji('<:Corbeille:1041823884661510145> ')
              .setStyle(ButtonStyle.Danger),
              new ButtonBuilder()
              .setCustomId('transcript')
              .setLabel('Demander le transcript')
              .setEmoji('<:Transcript:1041824048763637901> ')
              .setStyle(ButtonStyle.Primary),
                );
     
     
            await channel.send({embeds: [EmbedCreateChannel], components: [Row]})
     
            const EmbedSuccessCreateChannel = new EmbedBuilder()
              .setColor("#545454")
              .setDescription(`<:yttr:1038591074312143029> Votre salon a été créé avec succès ${channel} !`)
     
            await interaction.followUp({embeds: [EmbedSuccessCreateChannel], ephemeral: true})
          }
        }
    }
}