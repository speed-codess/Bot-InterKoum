const { EmbedBuilder } = require("discord.js");

module.exports = {
    name: "ping",
    description: "Affiche la Latence du bot",
    type: 1,
    category: "Information & Fun",
    options: [],
    permissions: {
        DEFAULT_MEMBER_PERMISSIONS: "SendMessages"
    },
    run: async (client, interaction, config) => {
        return interaction.reply({
            embeds: [
                new EmbedBuilder()
                    .setDescription(client.ws.ping + " Ms")
                    .setColor('0x545454')
            ],
            ephemeral: true
        })
    },
}