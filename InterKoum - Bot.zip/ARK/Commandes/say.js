const Discord = require('discord.js');

module.exports = {

    name: "say",
    description: "Dites un message avec le bot",
    permission: Discord.PermissionFlagsBits.ManageMessages,
    category: "Modération",
    usage: "/say",
    dm: false,
    options: [
        {
            type: "string",
            name: "message",
            description: "Le message que vous souhaitez envoyer avec le bot",
            required: true,
            autocomplete: false
        },
    ],

    async run(bot, message, args) {

        let messages = args.getString('message')

        try{
            
            let SuccesEmbedBot = new Discord.EmbedBuilder()
                .setDescription("**Envoyé avec succès votre message !**")
                .setColor("#545454")

            message.reply({embeds: [SuccesEmbedBot], ephemeral: true})
            await message.channel.send({content: `${messages}`})
        
        }catch(err) {console.log(err)}
    }
}
