const Discord = require('discord.js')
const { EmbedBuilder } = require("discord.js")
const { color } = require('../config')

module.exports = {

  name: "embed",
  description: "Permet d'envoyer un message en embed",
  permission: Discord.PermissionFlagsBits.ManageMessages,
  dm: false,
  category: "Modération",

async run(bot, message, args) {
        const EmbedMessage  = new EmbedBuilder()
            .setColor(0x0066ff)
            .setDescription(`L'embed marche`)

            message.channel.send({ embeds: [EmbedMessage ] });
            message.reply({content: "Embed envoyer avec succès !", ephemeral: true});
  }
}