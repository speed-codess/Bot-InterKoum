const Discord = require('discord.js');
const { EmbedBuilder } = require('discord.js');
const { ButtonBuilder } = require('discord.js')
const { ActionRowBuilder } = require('discord.js')
const { ApplicationCommandType } = require('discord.js')
const { ApplicationCommandOptionType  } = require('discord.js')

module.exports = {
    name: "avatar",
    description: "Permet d'Avoir l'Avatar d'un Membre",
    permission: "Aucune",
    dm: true,
    category: "Information & Fun",
    options: [
        {
        type: "user",
        name: "utlisateur",
        description: "l'utlisateur a avoir l'avatar",
        required: false,
        autocomplete: false,
        }
    ],
    
    run: async (client, interaction) => {
        let user = interaction.options.get('utlisateur')?.user || interaction.user;

        const embed = new EmbedBuilder()
        .setTitle(`${user.tag} avatar`)
        .setImage(user.displayAvatarURL({ size: 4096 }))
        .setColor("545454")
        .setTimestamp();

        const formats = ['png', 'jpg', 'jpeg', 'gif'];
        const components = [];
        formats.forEach(format => {
            let imageOptions = { extension: format, forceStatic: format == 'gif' ? false : true };

            if (user.avatar == null && format !== 'png') return; 
            if (!user.avatar.startsWith('a_') && format === 'gif') return;
            components.push(
                new ButtonBuilder()
                .setLabel(format.toUpperCase())
                .setStyle('Link')
                .setURL(user.displayAvatarURL(imageOptions))
            )
        })

        const row = new ActionRowBuilder()
        .addComponents(components);

        return interaction.reply({ embeds: [embed], components: [row], ephemeral: true})
    }
};