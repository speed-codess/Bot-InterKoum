const Discord = require('discord.js')
const { EmbedBuilder } = require("discord.js");
const interactionCreate = require('../Events/interactionCreate');

module.exports = {

  name: "report",
  description: "Permet de report une personne",
  permission: "Aucune",
  dm: false,
  category: "Autres",
  options: [
    {
        type: "user",
        name: "user",
        description: "La personne a report.",
        required: true,
        autocomplete: false
    },
    {
        type: "string",
        name: "raison",
        description: "La raison du report.",
        required: true,
        autocomplete: false
    },
    
],

async run(bot, message, args) {
    message.reply({content: '**Report Envoyé avec succès ! **', ephemeral: true});
    let msg = args.getString("raison");
    let user = args.getUser("user");
        const EmbedMessage  = new EmbedBuilder()
            .setTitle(`Nouveau report !`)
            .setColor(0x545454)
            .setDescription(`${message.user} a report ${user} pour la raison suivante : \`\`\`${msg}\`\`\`\n `)

            bot.channels.cache.get("1044364559181418525").send({ embeds: [EmbedMessage] })
        }
}