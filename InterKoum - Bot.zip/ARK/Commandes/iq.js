const Discord = require("discord.js")

const { EmbedBuilder } = require('discord.js');

module.exports = ({

    name: 'iq',

    description: 'Permet de connaître son QI',

    permissions: "Aucune",

    dm: true,

    category: "Information & Fun",

    async run(client, message, args)  {

        let user = message.user;

        const amount = Math.floor(Math.random() * 100) + 1;

        const embed = new EmbedBuilder()

        .setDescription(` ‎ <@${user.id}> **votre IQ est a ${amount}% **`)

        .setColor("0x0066ff")

        message.reply({embeds: [embed], ephemeral: true})

      

    }

})