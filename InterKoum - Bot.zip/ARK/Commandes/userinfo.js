const Discord = require("discord.js");
const { EmbedBuilder } = require("discord.js")

module.exports = {

    name: "userinfo",
    description: "Permet de voir les information d'un utilisateur",
    dm: false,
    category: "Informations & Fun",
    options: [
        {
            type: "user",
            name: "membre",
            description: "Quel utilisateur ?",
            required: true
        },
    ],

    async run(bot, message, args) {

            const user = args.getUser("membre");
             let member = message.guild.members.cache.get(user.id)


            let userEmbed = new Discord.EmbedBuilder()
                .setColor("0x545454")
                .setThumbnail(member.user.displayAvatarURL())
                .setDescription(`
                __**User Informations**__

                > **Ping :** ${user.toString()}
                > **Name/Tag :** ${user.tag}
                > **ID :** ${user.id}
                > **Bot :** ${user.bot ? '<:oui:1040630042981576734>  ' : '<:nn:1040630316487946370>  '}

                __ ** Information Compte ** __

                > **Créer :** <t:${parseInt(user.createdTimestamp / 1000)}:R>
                > **A rejoins :** <t:${parseInt(member.joinedAt / 1000)}:R>`)

                await message.reply({ embeds: [userEmbed], ephemeral: true });
        }
    }