const Discord = require("discord.js")
const { EmbedBuilder, ActionRowBuilder, SelectMenuBuilder } = require("discord.js")
 
module.exports = {
 
  name: "ticket",
  description: "Envoyer l'embed des tickets",
  permission:  Discord.PermissionFlagsBits.Administrator,
  dm: false,
  category: "Administration",
 
  async run(bot, message, args) {
    const EmbedTicket = new EmbedBuilder()
    .setColor("#5271ff")
    .setDescription(`Panel à été envoyer avec succès !`)
 
    const EmbedTicket1 = new EmbedBuilder()
    .setColor("#545454")
    .setTitle(`Contacter le Staff ?`)
    .setThumbnail(`https://cdn.discordapp.com/attachments/1038089543175389244/1045432185840218195/a_9.png`)
    .setDescription(`VOTRE MESSAGE DE TICKET`)
    .setTimestamp()
    .setFooter({ text: `${bot.user.username}`, iconURL: bot.user.displayAvatarURL({dynamic: true}) });
 
    const RowTicket = new ActionRowBuilder()
            .addComponents(
      new SelectMenuBuilder()
      .setCustomId('menuticket')
      .setPlaceholder('Sélectionner le type de ticket que vous voulez !')
      .addOptions(
        {
          label: `Besoin d'aide`,
          description: `Ouvrir un ticket pour obtenir de l'aide`,
          emoji: `:TI:1045433853000560821>  `,
          value: `help`,
        },
        {
          label: "Achat",
          description: `Ouvrir un ticket pour passer un achat`,
          emoji: '<:10359981363107144601:1045434422226321538> ',
          value: "Achat",
        },
    ),
  );
 
   message.reply({embeds : [EmbedTicket], ephemeral : true})
   message.channel.send({embeds : [EmbedTicket1], components : [RowTicket]})
  }
}